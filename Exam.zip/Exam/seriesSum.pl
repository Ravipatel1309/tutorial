sum([],0).

sum([Head|Tail],Sum):-
    sum(Tail,Sum1),
    Sum is Sum1 + Head.

generate_list(1,[1]).
generate_list(N,List):-
    N > 1,
    N1 is N-1,
    generate_list(N1,List),
    append(L)

main:-
    sum([1,2,3,4,5,6,7,8,9,10],Sum),
    write("Sum is: "),write(Sum).